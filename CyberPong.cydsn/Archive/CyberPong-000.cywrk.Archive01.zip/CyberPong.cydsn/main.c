
#include "project.h"
#include "main_data.h"
#include "motorController.h"
#include "debug.h"
#include "aios.h"
#include "ballServeController.h"
#include "time.h"
#include <stdio.h>
#include <stdlib.h>


void turnDown(void){
    ENA_P_16_Write(1);
    IN1_P_01_Write(1);
    IN2_P_00_Write(0);
}

void turnUp(void){
    ENA_P_16_Write(1);
    IN1_P_01_Write(0);
    IN2_P_00_Write(1);
}
void stopMoving(){
    ENA_P_16_Write(0);
}


int main(void)
{
    CyGlobalIntEnable;
    
    // Set everything up
    FanController_Start();
    UART_Start();
    ISR_Ball_Trigger_StartEx(Pin_Input_BallTrigger_Handler);
    StopBallServe();
    // Bluetooth
    CyBle_Start(AIOS_Handler);
    CyBle_AiosRegisterAttrCallback(AIOS_Callback);
    
    // Set up flags
    disablePrintIfZeroRPM = false;
    
    motorsEnabled = true;
    SetMotorsEnabled(false);
    volatile int16 adcResult = 0;
    volatile int16 voltage = 0;
    char uartBuff[50u];
     
    
    ADC_Start();
    UART_UartPutString("Starting measurements...");
 
    CyDelay(1000);

    ENA_P_16_Write(0);
    int16 desired_voltage = 1800;
    // 1650 - lowest position
    // ~2100 - highest 
    for(;;)
    {  pin_motor_Write(1);
        ADC_StartConvert();
        adcResult = ADC_GetResult16(0);
        voltage = ADC_CountsTo_mVolts(0, adcResult);
        
        sprintf(uartBuff, "ADC voltage = %u mV \r\n",  voltage);
        UART_UartPutString(uartBuff);
        
        if (abs(voltage - desired_voltage) > 150){
            if (voltage > desired_voltage){               
                while (voltage > desired_voltage){    
                    turnUp();
                    ADC_StartConvert();
                    voltage = ADC_CountsTo_mVolts(0, ADC_GetResult16(0));
                }
                    
                                                    
            } else if (voltage < desired_voltage){
                while ( desired_voltage > voltage){
                        
                        turnDown();
                        ADC_StartConvert();
                        voltage = ADC_CountsTo_mVolts(0, ADC_GetResult16(0));
                    }
                    
                    
            }
            stopMoving();
            CyDelay(500);
        }
        Pin_Output_Serve_Write(1);
        CyBle_ProcessEvents();
        PrintMotorSpeeds();
        HandleUARTInput();
        CheckForBallServeRequest();
        UpdateServing();
    }
}

/* [] END OF FILE */
